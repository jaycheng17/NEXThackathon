import base64
import os
import shutil
from bs4 import BeautifulSoup
from strands import Agent
from strands.models import BedrockModel
import json
import urllib.request
import urllib.error
import boto3


# Send HTTP GET request
def getImageUrl(url):
    imageUrls = []
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Mozilla/5.0"}
        )
        with urllib.request.urlopen(req) as response:
            html = response.read()
            soup = BeautifulSoup(html, "html.parser")
            imgs = soup.find_all("img")
            for img in imgs:
                src = img.get("src")
                if src and "pinimg.com" in src and "236x" in src:
                    imageUrls.append(src)
    except urllib.error.URLError as e:
        print(f"Error fetching URL: {e}")
    
    return imageUrls

def downloadImages(imageUrls):
    imagesPath = []
    imageName = 1
    
    newpath = "/tmp/images"
    if not os.path.exists(newpath):
        os.makedirs(newpath)
        
    for url in imageUrls:
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0"}
            )
            with urllib.request.urlopen(req) as response:
                imagePath = f"{newpath}/{imageName}.jpg"
                with open(imagePath, "wb") as f:
                    f.write(response.read())
                imagesPath.append(imagePath)
                imageName += 1
        except urllib.error.URLError as e:
            print(f"Error downloading image: {e}")
    return imagesPath

def convertToJPEG(imagesPath):
    finalPath = []
    for imagePath in imagesPath:
        if imagePath.endswith(".jpg"):
            jpegPath = imagePath.rsplit(".jpg", 1)[0]
            os.rename(imagePath, jpegPath + ".jpeg")
            finalPath.append(jpegPath)
    return finalPath

# Prompting the AI
def encode_image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        encoded = base64.b64encode(image_file.read()).decode("utf-8")
    return encoded

def prompt_for_agent(image_path, text_prompt, count):
    prompts = []
    prompt = text_prompt
    for index in range(0, 5):
        img = image_path[index] + ".jpeg"
        image_base64 = encode_image_to_base64(img)
        prompt = prompt + f"\n\nImage: data:image/jpeg;base64,{image_base64}"
    prompts.append(prompt)
    return prompts


def callVectorDB(result):
    vectorDB_lambda_api = "https://9ao9cgmn11.execute-api.us-west-2.amazonaws.com/default/teste3"
    payload = {"query": result}
    headers = {
        "Content-Type": "application/json"}
    
    request = urllib.request.Request(
        vectorDB_lambda_api,
        data=json.dumps(payload).encode('utf-8'),
        headers=headers,
        method='POST'
    )


    with urllib.request.urlopen(request) as response:
        response_data = response.read().decode('utf-8')
        data = json.loads(response_data)
        return data['body']
  


def lambda_handler(event, context):
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "POST,OPTIONS"
            },
            'body': json.dumps("CORS preflight OK")
        }

    # Pinterest board URL
    pinterest_board_url = event.get("url")

    imageUrls = getImageUrl(pinterest_board_url)
    imagesPath = downloadImages(imageUrls[:5])
    finalPath = convertToJPEG(imagesPath)

    # Create a custom boto3 session
    session = boto3.Session(
        aws_access_key_id='ASIA3WWPJAH7TRDFUCRK',
        aws_secret_access_key='3WxdyhQ7qrdQ6gWDaOjmayMqopzjpElaU1ULkZJ+',
        aws_session_token='IQoJb3JpZ2luX2VjEKf//////////wEaCXVzLWVhc3QtMSJIMEYCIQC4wtNlLCZM3PVtqSEBYtp9Cb+lH8Gkufbz6ewFw+g5CwIhAIe8shxzSKfrajAZi52bw0fWMjXjFkuAkS3dJOtsRdBjKqICCJD//////////wEQARoMODA0NjY3MzI2OTc1Igx4Dprzbi9/Xvd1P0Uq9gHkBfgdFtZtJNcr7ma8+NWCjRsbV1EhgsoK/fnS23sXf1/SOMvnNuckgCZTsLU8Ae4FETAt2L93AMLd33W/4r88+RtstzKGy/5TZ8zGN6cRinvij0BkvRq3L1Q5I2dlI8efK5jbofUxDjdhicXvMIDQLAc1FLJKFtPAZKG6JWztNza2dLRioEt9pK28UhH05ltuR33MmzQUwr3LOO8ia6gpOWEikUbmdcR/ZxTHRhHB2Wyelt3GPHPsE9NkFT4MY8EvdeOg7jVsV6yv7YcVdLjS1mRKdSjd6PwDhdgeE6oQkVeblGm3Xx/y3QVNeKKmawXT45qwH2Ewg5fLwgY6nAFdJ6l1xQTOFDTnyXXS5KUbw2AqFTzsOknyDRuZfkfJliMqdEd1Cr9AszneDr953WTUhJsqcyDzopxf8Ger71GHBsU79nfmXcpYWfW7gukV9AErNjzHQ/o8jKhoLXkniV4ms6By+DVSJgryGdaIDWKWUi8DvocQGyhtpIx6pPB0qtZlY/vcT5ZZvlDLbkcDqNtwZ+H5otMx8a+WWmw='
    )

    bedrock_model = BedrockModel(
        model_id="us.anthropic.claude-3-5-sonnet-20241022-v2:0",
        temperature=0,
        top_p=0.9,
        top_k=50,
        boto_session=session
    )
    agent = Agent(model=bedrock_model)
    
    finalPrompts = prompt_for_agent(
        finalPath,
        "What do you see in this image? Can you suggest a wedding theme based on this image?",
        len(finalPath)
    )
    result = agent(finalPrompts[0])

    shutil.rmtree("/tmp/images")


    result = str(result)
    # to change to another lambda call
    finalResult = callVectorDB(result)

    return {
        "statusCode": 200,
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "POST,OPTIONS"
        },
        "body": json.dumps(str(finalResult))
    }
